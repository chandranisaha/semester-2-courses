SELECT Pname, Pnumber
FROM PROJECT
WHERE Plocation = 'Houston';
