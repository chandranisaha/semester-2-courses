SELECT Fname, Lname, Salary
FROM EMPLOYEE;
