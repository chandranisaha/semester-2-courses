SELECT Dno, MAX(Salary) AS Highest_Salary
FROM EMPLOYEE
GROUP BY Dno;
