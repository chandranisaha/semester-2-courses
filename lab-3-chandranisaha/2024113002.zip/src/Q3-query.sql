SELECT Fname, Lname, Salary
FROM EMPLOYEE
WHERE Salary > 30000;
